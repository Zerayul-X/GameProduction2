#include <functional>
#include <iostream>
#include <string>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include "FSM.h"
#include "Engine.h"
#include "Button.h"
#include "Utilities.h"
#include <ctime>
#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;

#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
#define BGSCROLL 2 // Could these scroll/speed values be handled in the class? Yes. Consider it!
// Begin State. CTRL+M+H and CTRL+M+U to turn on/off collapsed code.
void State::HandleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			Engine::Instance().QuitGame();
			break;
		case SDL_KEYDOWN: // Try SDL_KEYUP instead.
			if (event.key.keysym.sym == SDLK_ESCAPE)
				Engine::Instance().QuitGame();
			break;
		case SDL_MOUSEBUTTONDOWN:
			if (event.button.button >= 1 && event.button.button <= 3)
				Engine::Instance().SetMouseState(event.button.button - 1, true);
			break;
		case SDL_MOUSEBUTTONUP:
			if (event.button.button >= 1 && event.button.button <= 3)
				Engine::Instance().SetMouseState(event.button.button - 1, false);
			break;
		case SDL_MOUSEMOTION:
			SDL_GetMouseState(&Engine::Instance().GetMousePos().x, &Engine::Instance().GetMousePos().y);
			break;
		}
	}
}
void State::Render()
{
	SDL_RenderPresent(Engine::Instance().GetRenderer());
}
void State::Resume() {}
// End State.

// Begin TitleState.
TitleState::TitleState() {}

void TitleState::Enter()
{
	cout << "Entering Title..." << endl;
	Mix_HaltMusic();
	ifQuit = false;
	m_vButtons.push_back(new PlayButton("Img/playButton.png", { 0,0,250,200 }, { 100,50,250,200 }));
	
	m_vButtons.push_back(new HighScoreBtn("Img/leadButton.png", { 0,0,400,200 }, { 312,250,400,200 }));

	m_vButtons.push_back(new ExitButton("Img/exitButton.png", { 0,0,250,200 }, { 650,500,250,200 }));
}

void TitleState::Update()
{
	if (!ifQuit) {
		for (int i = 0; i < (int)m_vButtons.size(); i++) {
			m_vButtons[i]->Update();
		}
	}
}

void TitleState::Render()
{
	cout << "Rendering Title..." << endl;
	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 255, 0, 0, 255);
	SDL_RenderClear(Engine::Instance().GetRenderer());

	//The title page background
	Sprite title = { {0,0,1024,768}, {0,0,1024,768} };
	SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetTitleTexture(),
		title.GetSrcP(), title.GetDstP());

	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	State::Render();
}
void TitleState::HandleEvents()
{
	State::HandleEvents(); // Don't need any events specific to TitleState.
}
void TitleState::Exit()
{
	cout << "Exiting Title..." << endl;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	ifQuit = true;
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}
// End TitleState.

//Begin Choose state
ChooseState::ChooseState() {}

void ChooseState::Enter() {
	cout << "Entering Title..." << endl;
	Mix_HaltMusic();
	ifQuit = false;
	m_vButtons.push_back(new Choice1Button("Img/ship1Button.png", { 0,0,100,100 }, { 100,300,100,100 }));
	// For the bind: what function, what instance, any parameters.
	m_vButtons.push_back(new Choice2Button("Img/ship2Button.png", { 0,0,100,100 }, { 462,300,100,100 }));

	m_vButtons.push_back(new Choice3Button("Img/ship3Button.png", { 0,0,100,100 }, { 824,300,100,100 }));
}
void ChooseState::Update() {
	if (!ifQuit) {
		for (int i = 0; i < (int)m_vButtons.size(); i++) {
			m_vButtons[i]->Update();
		}
	}
}
void ChooseState::HandleEvents() {
	State::HandleEvents(); // Don't need any events specific to TitleState.
}
void ChooseState::Render() {
	cout << "Rendering Title..." << endl;
	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 255, 0, 0, 255);
	SDL_RenderClear(Engine::Instance().GetRenderer());

	//The title page background
	Sprite choose = { {0,0,1024,768}, {0,0,1024,768} };
	SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetChooseTexture(),
		choose.GetSrcP(), choose.GetDstP());

	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	State::Render();
}
void ChooseState::Exit() {
	cout << "Exiting Title..." << endl;
	ifQuit = true;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}
//End Choose state

//Begin HighScore state
HighScore::HighScore() {}

void HighScore::Enter() {
	cout << "Entering Title..." << endl;
	Mix_HaltMusic();
	ifQuit = false;
	m_vButtons.push_back(new BackToMain("Img/backButton.png", { 0,0,100,50 }, { 25,25,100,50 }));
	m_pTimerFont = TTF_OpenFont("Img/CaviarDreams.ttf", 40);
}
void HighScore::Update() {
	if (!ifQuit) {
		for (int i = 0; i < (int)m_vButtons.size(); i++) {
			m_vButtons[i]->Update();
		}
	}
}
void HighScore::HandleEvents() {
	State::HandleEvents(); // Don't need any events specific to TitleState.
}
void HighScore::RenderFont(bool r, const char* c, int x, int y)
{
	//Render check
	if (r)
	{
		SDL_Color textColor = { 255, 255, 255, 0 }; //White text
		//Render text 
		SDL_Surface* fontSurf = TTF_RenderText_Solid(m_pTimerFont, c, textColor);
		SDL_DestroyTexture(m_pTimerText); //Need to de-allocate previous font texture
		m_pTimerText = SDL_CreateTextureFromSurface(Engine::Instance().GetRenderer(), fontSurf);
		m_rFontRect = { x, y, fontSurf->w, fontSurf->h };
		SDL_FreeSurface(fontSurf);
	}
	SDL_RenderCopy(Engine::Instance().GetRenderer(), m_pTimerText, 0, &m_rFontRect);
}
void HighScore::Render() {
	cout << "Rendering Title..." << endl;
	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 255, 0, 0, 255);
	SDL_RenderClear(Engine::Instance().GetRenderer());

	//The title page background
	Sprite choose = { {0,0,1024,768}, {0,0,1024,768} };
	SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetBGTexture(),
		choose.GetSrcP(), choose.GetDstP());
	
	
	//XML
	XMLDocument xmlDoc;
	xmlDoc.LoadFile("gameData.xml");
	XMLElement* pRoot = xmlDoc.FirstChildElement();
	XMLElement* pElement = pRoot->FirstChildElement();
	int counter = 0;
	int score[5];
	int time[5];
	for (int i = 0; i < 5; i++) {
		score[i] = 0;
		time[i] = 0;
	}
	while (pElement != nullptr) {
		cout << "I see a " << pElement->Value() << endl;
		if (strcmp(pElement->Value(), "Player") == 0)
		{
			pElement->QueryIntAttribute("score", &score[counter]);
			pElement->QueryIntAttribute("time", &time[counter]);
			counter++;
		}
		pElement = pElement->NextSiblingElement();

	}
	m_Score1 = "Score: " + to_string(score[0]);
	RenderFont(true, m_Score1.c_str(), 200, 125);
	m_Score2 = "Score: " + to_string(score[1]);
	RenderFont(true, m_Score2.c_str(), 200, 250);
	m_Score3 = "Score: " + to_string(score[2]);
	RenderFont(true, m_Score3.c_str(), 200, 375);
	m_Score4 = "Score: " + to_string(score[3]);
	RenderFont(true, m_Score4.c_str(), 200, 500);
	m_Score5 = "Score: " + to_string(score[4]);
	RenderFont(true, m_Score5.c_str(), 200, 625);

	m_Time1 = "Time Used: " + to_string(time[0]);
	RenderFont(true, m_Time1.c_str(), 550, 125);
	m_Time2 = "Time Used: " + to_string(time[1]);
	RenderFont(true, m_Time2.c_str(), 550, 250);
	m_Time3 = "Time Used: " + to_string(time[2]);
	RenderFont(true, m_Time3.c_str(), 550, 375);
	m_Time4 = "Time Used: " + to_string(time[3]);
	RenderFont(true, m_Time4.c_str(), 550, 500);
	m_Time5 = "Time Used: " + to_string(time[4]);
	RenderFont(true, m_Time5.c_str(), 550, 625);
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	State::Render();
}
void HighScore::Exit() {
	cout << "Exiting Title..." << endl;
	ifQuit = true;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}
//End HighScore state

// Begin GameState.
GameState::GameState() {}

void GameState::Enter()
{
	cout << "Entering Game..." << endl;
	Engine::Instance().PlayBGM();
	Engine::Instance().FindMaxArmour();
	shotEnable = false;
	shotTime = 0;
	m_pTimerFont = TTF_OpenFont("Img/00021_01DigiGraphics.ttf", 30);
	m_iCurrTime = m_iTimeCtr = 0;
	m_iLastTime = -1;
}

void GameState::HandleEvents()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // User pressed window's 'x' button.
			Engine::Instance().SetRunning(false);
			break;
		case SDL_KEYDOWN: // Try SDL_KEYUP instead.
			if (event.key.keysym.sym == SDLK_ESCAPE)
				Engine::Instance().SetRunning(false);
			break;
		case SDL_KEYUP:
			if (event.key.keysym.sym == SDLK_SPACE)
				shotEnable = true;
			break;
		}
	}

	//shot counter, count for frames
	if (shotEnable) {
		switch (Engine::Instance().GetPlayerShip()) {
		case 1://1.5s
			shotTime++;
			if (shotTime >= 90) {
				Engine::Instance().SetCanshot(true);
				shotTime = 0;
				shotEnable = false;
			}
			break;
		case 2://0.66s
			shotTime++;
			if (shotTime >= 40) {
				Engine::Instance().SetCanshot(true);
				shotTime = 0;
				shotEnable = false;
			}
			break;
		case 3://0.33s
			shotTime++;
			if (shotTime >= 20) {
				Engine::Instance().SetCanshot(true);
				shotTime = 0;
				shotEnable = false;
			}
			break;
		default:
			break;
		}
	}

	// Now enemy bullets
	for (int i = 0; i < (int)Engine::Instance().GetVecEmyBullet().size(); i++)
	{
		Engine::Instance().GetVecEmyBullet()[i]->Update();
		if (Engine::Instance().GetVecEmyBullet()[i]->GetDstP()->y > HEIGHT + 10)
		{
			Engine::Instance().CleanSingleEB(i);
		}
	}
	if (Engine::Instance().GetEBNull()) Engine::Instance().CleanEBVec();
	Engine::Instance().CheckCollision();
}

void GameState::RenderFont(bool r, const char* c, int x, int y)
{
	//Render check
	if (r)
	{
		SDL_Color textColor = { 255, 255, 255, 0 }; //White text
		//Render text 
		SDL_Surface* fontSurf = TTF_RenderText_Solid(m_pTimerFont, c, textColor);
		SDL_DestroyTexture(m_pTimerText); //Need to de-allocate previous font texture
		m_iCurrTime = Engine::Instance().GetTotalFrame() / FPS;
		m_sTime = "TIME: " + to_string(m_iCurrTime);
		m_pTimerText = SDL_CreateTextureFromSurface(Engine::Instance().GetRenderer(), fontSurf);
		m_rFontRect = { x, y, fontSurf->w, fontSurf->h };
		SDL_FreeSurface(fontSurf);
	}
	SDL_RenderCopy(Engine::Instance().GetRenderer(), m_pTimerText, 0, &m_rFontRect);
}

void GameState::Update()
{
	//Time counter
	m_iTimeCtr++;

	//recover the player's armour
	Engine::Instance().RecoverArmour();

	//frame++
	Engine::Instance().UpdateTotalFrame();

	//player's choice
	cout << Engine::Instance().GetPlayerShip() << endl;

	//update
	Engine::Instance().UpdateFrameCounter();

	//key event
	if (Engine::Instance().KeyDown(SDL_SCANCODE_P) == 1)
	{
		Engine::Instance().GetFSM().PushState(new PauseState());
		return;
	}
	else if (Engine::Instance().KeyDown(SDL_SCANCODE_X) == 1)
	{
		Engine::Instance().GetFSM().ChangeState(new ChooseState());
		return;
	}
	else if (Engine::Instance().KeyDown(SDL_SCANCODE_I) == 1)
	{
		Engine::Instance().ChangeInstr();
		return;
	}
	// Scroll the backgrounds. Check if they need to snap back.
	for (int i = 0; i < 2; i++)
	{
		Engine::Instance().GetBgArray()[i].GetDstP()->y += BGSCROLL;
	}
	if (Engine::Instance().GetBgArray()[1].GetDstP()->y >= 768)
	{
		Engine::Instance().GetBgArray()[0].GetDstP()->y = -768;
		Engine::Instance().GetBgArray()[1].GetDstP()->y = 0;
	}

	Engine::Instance().PlayerAnimation();

	// Enemy animation/movement.
	for (int i = 0; i < (int)Engine::Instance().GetVecEnemies().size(); i++)
	{
		Engine::Instance().GetVecEnemies()[i]->Update(); // Oh, again! We're telling the enemies to update themselves. Good good!
		if (Engine::Instance().GetVecEnemies()[i]->GetDstP()->y > HEIGHT + 100)
		{
			Engine::Instance().CleanSingleEmy(i);
		}
	}
	if (Engine::Instance().GetEmyNull()) Engine::Instance().CleanEmyVec(); // Better to have a logic check (if) than a function call all the time!

	Engine::Instance().UpdateEmySpawn();

	// Update the bullets. Player's first.
	for (int i = 0; i < (int)Engine::Instance().GetVecPlyBullet().size(); i++)
	{
		Engine::Instance().GetVecPlyBullet()[i]->Update();
		if (Engine::Instance().GetVecPlyBullet()[i]->GetDstP()->y < 0)
		{
			Engine::Instance().CleanSinglePB(i);
		}
	}
	if (Engine::Instance().GetPBNull()) Engine::Instance().CleanPBVec();
}

void GameState::Render()
{
	cout << "Rendering Game..." << endl;

	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 111, 122, 222, 255);
	SDL_RenderClear(Engine::Instance().GetRenderer()); // Clear the screen with the draw color.

	
	//background
	for (int i = 0; i < 2; i++) {
		SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetBGTexture(),
			Engine::Instance().GetBgArray()[i].GetSrcP(), Engine::Instance().GetBgArray()[i].GetDstP());
	}
	//player sprite
	if (Engine::Instance().GetIfAlive()) {
		switch (Engine::Instance().GetPlayerShip()) {
		case 1:
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip1Texture(),
				Engine::Instance().GetPlayer()->GetSrcP(), Engine::Instance().GetPlayer()->GetDstP(),
				Engine::Instance().GetPlayer()->GetAngle(), &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
			break;
		case 2:
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip2Texture(),
				Engine::Instance().GetPlayer()->GetSrcP(), Engine::Instance().GetPlayer()->GetDstP(),
				Engine::Instance().GetPlayer()->GetAngle(), &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
			break;
		case 3:
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip3Texture(),
				Engine::Instance().GetPlayer()->GetSrcP(), Engine::Instance().GetPlayer()->GetDstP(),
				Engine::Instance().GetPlayer()->GetAngle(), &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
			break;
		default:
			break;
		}
	}
	else {
		Engine::Instance().RenderAndUpdateExplo();
	}

	//player bullet
	switch (Engine::Instance().GetPlayerShip()) {
	case 1:
		for (int i = 0; i < (int)Engine::Instance().GetVecPlyBullet().size(); i++)
		{
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip1Bullet(),
				Engine::Instance().GetVecPlyBullet()[i]->GetSrcP(), Engine::Instance().GetVecPlyBullet()[i]->GetDstP(),
				0, &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
		}
		break;
	case 2:
		for (int i = 0; i < (int)Engine::Instance().GetVecPlyBullet().size(); i++)
		{
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip2Bullet(),
				Engine::Instance().GetVecPlyBullet()[i]->GetSrcP(), Engine::Instance().GetVecPlyBullet()[i]->GetDstP(),
				0, &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
		}
		break;
	case 3:
		for (int i = 0; i < (int)Engine::Instance().GetVecPlyBullet().size(); i++)
		{
			SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetShip3Bullet(),
				Engine::Instance().GetVecPlyBullet()[i]->GetSrcP(), Engine::Instance().GetVecPlyBullet()[i]->GetDstP(),
				0, &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
		}
		break;

	}
	
	////enemy bullet
	for (int i = 0; i < (int)Engine::Instance().GetVecEmyBullet().size(); i++)
	{
		SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetPlayerTexture(),
			Engine::Instance().GetVecEmyBullet()[i]->GetSrcP(), Engine::Instance().GetVecEmyBullet()[i]->GetDstP());
	}

	//ememy
	for (int i = 0; i < (int)Engine::Instance().GetVecEnemies().size(); i++)
	{
		SDL_RenderCopyEx(Engine::Instance().GetRenderer(), Engine::Instance().GetEmy1Texture(),
			Engine::Instance().GetVecEnemies()[i]->GetSrcP(), Engine::Instance().GetVecEnemies()[i]->GetDstP(),
			-90, &Engine::Instance().GetPivot(), SDL_FLIP_NONE);
	}

	//Render timer
	m_iCurrTime = Engine::Instance().GetTotalFrame() / FPS;
	m_sTime = "TIME: " + to_string(m_iCurrTime);
	RenderFont(/*(m_iLastTime < m_iCurrTime ? 1 : 0)*/true, m_sTime.c_str(), 830, 25);
	m_iLastTime = m_iCurrTime;
	m_sScore = "Score: " + to_string(Engine::Instance().GetScore());
	RenderFont(true, m_sScore.c_str(), 10, 50);

	if (Engine::Instance().GetTotalFrame() / FPS <= 3) {
		instruction = "Stage 1: The Void";
		RenderFont(true, instruction.c_str(), 350, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 4) {}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 7) {
		instruction = "Use 'W','A','S','D' for Movement";
		RenderFont(Engine::Instance().IfInstruction(), instruction.c_str(), 225, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 8) {}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 10) {
		instruction = "Use Spacebar to Shot";
		RenderFont(Engine::Instance().IfInstruction(), instruction.c_str(), 295, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 11) {}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 14) {
		instruction = "Press 'X' go back to Ship Selection";
		RenderFont(Engine::Instance().IfInstruction(), instruction.c_str(), 205, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 15) {}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 18) {
		instruction = "And Press 'P' to Pause. Good Luck!";
		RenderFont(Engine::Instance().IfInstruction(), instruction.c_str(), 215, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 28) { }
	else if (Engine::Instance().GetTotalFrame() / FPS <= 34) {
		instruction = "Stage 2: Super Nova";
		RenderFont(true, instruction.c_str(), 320, 300);
	}
	else if (Engine::Instance().GetTotalFrame() / FPS <= 57) { }
	else if (Engine::Instance().GetTotalFrame() / FPS <= 63) {
		instruction = "Stage 3: Big Bang";
		RenderFont(true, instruction.c_str(), 340, 300);
	}

	Engine::Instance().RenderArmor();
	SDL_RenderPresent(Engine::Instance().GetRenderer());
	State::Render();
}

void GameState::Exit()
{
	cout << "Exiting Game..." << endl;
}

void GameState::Resume() { cout << "Resuming Game..." << endl; }
// End GameState.

// Begin PauseState.
PauseState::PauseState() {}

void PauseState::Enter()
{
	cout << "Entering Pause..." << endl;
	m_vButtons.push_back(new ResumeButton("Img/resumeButton.png", { 0,0,400,100 }, { 312,50,400,100 }));
	// This exit button has a different size but SAME function as the one in title.
	m_vButtons.push_back(new ExitButton("Img/exitButton_B.png", { 0,0,400,100 }, { 312,200,400,100 }));
	Mix_HaltChannel(-1);
}
void PauseState::HandleEvents()
{
	State::HandleEvents();
}

void PauseState::Update()
{
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Update();
}

void PauseState::Render()
{
	cout << "Rendering Pause..." << endl;
	SDL_SetRenderDrawBlendMode(Engine::Instance().GetRenderer(), SDL_BLENDMODE_BLEND);
	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 88, 88, 88, 8);
	//SDL_Rect rect = { 256, 128, 512, 512 }; //window size
	SDL_Rect rect = { 0, 0, 1024, 768 };
	SDL_RenderFillRect(Engine::Instance().GetRenderer(), &rect);
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	FC_Font* font = FC_CreateFont();
	FC_LoadFont(font, Engine::Instance().GetRenderer(), "Img/LTYPE.TTF", 35, FC_MakeColor(240, 240, 240, 255), TTF_STYLE_NORMAL);
	FC_Draw(font, Engine::Instance().GetRenderer(), 100, 350, "Controls:");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 400, "W - move player up");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 450, "A - move player left");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 500, "S - move player down");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 550, "D - move player right");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 600, "X - select another ship");
	FC_Draw(font, Engine::Instance().GetRenderer(), 10, 650, "Spacebar - shoot beam");
	FC_Draw(font, Engine::Instance().GetRenderer(), 700, 350, "Objective:");
	FC_Draw(font, Engine::Instance().GetRenderer(), 650, 400, "Dodge and shoot");
	FC_Draw(font, Engine::Instance().GetRenderer(), 650, 450, "enemies. Last as");
	FC_Draw(font, Engine::Instance().GetRenderer(), 650, 500, "long as you can.");
	FC_Draw(font, Engine::Instance().GetRenderer(), 650, 550, "I - close/open");
	FC_Draw(font, Engine::Instance().GetRenderer(), 650, 600, "instructions.");
	State::Render();
}

void PauseState::Exit()
{
	cout << "Exiting Pause..." << endl;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}

void PauseState::Resume()
{
	cout << "Exiting Pause..." << endl;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
}
// End PauseState.

// Begin LoseState.
LoseState::LoseState() {}

void LoseState::Enter()
{
	cout << "Entering Lose..." << endl;
	ifQuit = false;
	m_vButtons.push_back(new RestartButton("Img/restartButton.png", { 0,0,400,100 }, { 312,200,400,100 }));
	// This exit button has a different size but SAME function as the one in title.
	m_vButtons.push_back(new ExitButton("Img/exitButton_B.png", { 0,0,400,100 }, { 312,400,400,100 }));
	Mix_HaltChannel(-1);

	////save back to XML
	XMLDocument xmlDoc;
	xmlDoc.LoadFile("gameData.xml");

	XMLElement* pRoot = xmlDoc.FirstChildElement();
	XMLElement* pElement = pRoot->FirstChildElement();
	int scoreVal;
	bool ifBreak;
	while (pElement != nullptr) {
		cout << "I see a " << pElement->Value() << endl;
		if (strcmp(pElement->Value(), "Player") == 0)
		{
			// "Gets" what'stored in name
			pElement->QueryIntAttribute("score", &scoreVal);
			if (Engine::Instance().GetScore() > scoreVal) {
				pElement->SetAttribute("score", Engine::Instance().GetScore());
				pElement->SetAttribute("time", Engine::Instance().GetTotalFrame() / FPS);
				break;
			}
		}
		pElement = pElement->NextSiblingElement();

	}
	xmlDoc.SaveFile("gameData.xml");
}

void LoseState::Update()
{
	if (!ifQuit) {
		for (int i = 0; i < (int)m_vButtons.size(); i++) {
			m_vButtons[i]->Update();
		}
	}
}

void LoseState::HandleEvents()
{
	State::HandleEvents();
}

void LoseState::Render()
{
	cout << "Rendering Lose..." << endl;
	SDL_SetRenderDrawBlendMode(Engine::Instance().GetRenderer(), SDL_BLENDMODE_BLEND);
	SDL_SetRenderDrawColor(Engine::Instance().GetRenderer(), 16, 32, 64, 64);

	/*Sprite lose = { {0, 0, 512, 512}, {256, 128, 512, 512} };
	SDL_RenderCopy(Engine::Instance().GetRenderer(), Engine::Instance().GetLoseTexture(),
		lose.GetSrcP(), lose.GetDstP());*/


	//SDL_Rect rect = { 256, 128, 512, 512 };
	//SDL_RenderFillRect(Engine::Instance().GetRenderer(), &rect);
	for (int i = 0; i < (int)m_vButtons.size(); i++)
		m_vButtons[i]->Render();
	State::Render();
}

void LoseState::Exit()
{
	cout << "Exiting Lose..." << endl;
	for (int i = 0; i < (int)m_vButtons.size(); i++)
	{
		delete m_vButtons[i];
		m_vButtons[i] = nullptr;
	}
	ifQuit = true;
	m_vButtons.clear();
	m_vButtons.shrink_to_fit();
	Engine::Instance().Reset();
}
// End PauseState.


// Begin StateMachine.
void FSM::Update()
{
	if (!m_vStates.empty()) // empty() and back() are methods of the vector type.
		m_vStates.back()->Update();
}

void FSM::Render()
{
	if (!m_vStates.empty())
		m_vStates.back()->Render();
}
void FSM::HandleEvents()
{
	if (!m_vStates.empty())
		m_vStates.back()->HandleEvents();
}
void FSM::ChangeState(State* pState)
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->Exit();
		delete m_vStates.back();	// De-allocating the state in the heap.
		m_vStates.back() = nullptr; // Nullifying pointer to the de-allocated state.
		m_vStates.pop_back();		// Removes the now-null pointer from the vector.
	}
	PushState(pState); // Invokes method below.
}

void FSM::PushState(State* pState)
{
	m_vStates.push_back(pState);
	m_vStates.back()->Enter();
}

void FSM::PopState()
{
	if (!m_vStates.empty())
	{
		m_vStates.back()->Exit();
		delete m_vStates.back();
		m_vStates.back() = nullptr;
		m_vStates.pop_back();
	}
	m_vStates.back()->Resume();
}

void FSM::Clean()
{
	while (!m_vStates.empty()) // Because we can exit the game in the pause state with the window's 'X'.
	{						   // Ensures that ALL states left in the vector are cleaned up.
		m_vStates.back()->Exit();
		delete m_vStates.back();
		m_vStates.back() = nullptr;
		m_vStates.pop_back();
	}
}

vector<State*>& FSM::GetStates() { return m_vStates; }
// End StateMachine.