#pragma once
#include <SDL.h>
#include <vector>
#include <algorithm>
#include <SDL_image.h>
#include <random>
#include <time.h>
#include <SDL_mixer.h>

#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
#define BGS 2

#define emyW 100
#define emyH 100
#define obW 50
#define obH 50
#define miniObW 25
#define miniObH 25
#define emyBulletW 55
#define emyBulletH 50
#define playerSizeW 149
#define playerSizeH 198
#define emyBulletSpeed 4
#define playBulletSpeed 5
using namespace std;

class Obstacle_small: public Sprite
{
public:
	bool m_active = true;

public:
	Obstacle_small(SDL_Rect d = { 0,0,0,0 }) // Note the default parameters.
	{
		m_dst = d;
	}
	void update()
	{
		//speed is random between 5 - 14
		int tempSpeed;
		srand((unsigned)time(NULL));
		tempSpeed = (rand() * 251) % 10 + 5; //makes this one differ from larger one
		m_dst.x -= tempSpeed;
		if (m_dst.x < 0 - m_dst.w) {// if obstacles get off the screen
			m_dst.x = 0 - m_dst.w;
			m_active = false;
		}
	}
};