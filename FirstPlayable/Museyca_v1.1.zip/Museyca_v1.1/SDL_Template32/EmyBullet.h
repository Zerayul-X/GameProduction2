#pragma once
#include <SDL.h>
#include <vector>
#include <algorithm>
#include <SDL_image.h>
#include <random>
#include <time.h>
#include <SDL_mixer.h>

#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
#define BGS 2

#define emyW 100
#define emyH 100
#define obW 50
#define obH 50
#define miniObW 25
#define miniObH 25
#define emyBulletW 55
#define emyBulletH 50
#define playerSizeW 149
#define playerSizeH 198
#define emyBulletSpeed 4
#define playBulletSpeed 5
using namespace std;

class EmyBullet: public Sprite // Inherits m_dst from Sprite.
{
public:
	bool m_active = true;
	EmyBullet(SDL_Rect d)
	{
		m_dst = d;
	}
	void update()
	{
		m_dst.y += emyBulletSpeed; // speed.
		if (m_dst.y >= HEIGHT) { // Off-screen.
			m_active = false;
		}
	}
};