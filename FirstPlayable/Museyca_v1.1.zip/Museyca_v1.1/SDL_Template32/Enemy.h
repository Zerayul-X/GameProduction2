#pragma once
#include <SDL.h>
#include <vector>
#include <algorithm>
#include <SDL_image.h>
#include <random>
#include <time.h>
#include <SDL_mixer.h>

#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
#define BGS 2

#define emyW 100
#define emyH 100
#define obW 50
#define obH 50
#define miniObW 25
#define miniObH 25
#define emyBulletW 55
#define emyBulletH 50
#define playerSizeW 149
#define playerSizeH 198
#define emyBulletSpeed 4
#define playBulletSpeed 5
using namespace std;

class Enemy : public Sprite
{
public:
	int m_bulletTimer = 0, m_timerMax, m_channel;
	vector<EmyBullet*>* bulletVec; // A pointer to a vector. NOT a vector on its own.
	bool m_active = true;
	Mix_Chunk* m_pSound;
public:
	Enemy(SDL_Rect d = { 0,0,0,0 }, vector<EmyBullet*>* bVec = nullptr, Mix_Chunk* s = nullptr, int c = 0, int t = 120) // Note the default parameters.
	{
		m_dst = d;
		bulletVec = bVec;
		m_pSound = s;
		m_channel = c;
		m_timerMax = t;
	}
	void update()
	{
		srand((unsigned)time(NULL));
		if (rand() % 3 == 0) {
			m_dst.x += 1;
		}
		else if (rand() % 3 == 1) {
			m_dst.x -= 1;
		}

		m_dst.y += 2;

		if (m_bulletTimer++ == m_timerMax)
		{
			m_bulletTimer = 0;
			spawnBullet();
		}
		if (m_dst.y >= HEIGHT + m_dst.h / 4) {// if enemy get off the screen
			m_dst.y = HEIGHT + m_dst.h / 4;
			m_active = false;
		}
		if (m_dst.x <= 0 - m_dst.w / 4) {// if enemy get off the screen
			m_dst.x = 0 - m_dst.w / 4;
			m_active = false;
		}
		if (m_dst.x >= WIDTH + m_dst.w / 4) {// if enemy get off the screen
			m_dst.x = WIDTH + m_dst.w / 4;
			m_active = false;
		}
	}
	void spawnBullet()
	{ // Note the -> because we have a POINTER to a vector.
		//set the size/location of the bullet
		bulletVec->push_back(new EmyBullet({ m_dst.x, m_dst.y, emyBulletW, emyBulletH }));

		Mix_PlayChannel(m_channel, m_pSound, 0);
	}
};