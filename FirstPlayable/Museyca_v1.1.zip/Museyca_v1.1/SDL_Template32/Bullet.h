#pragma once
#include <SDL.h>
#include <vector>
#include <algorithm>
#include <SDL_image.h>
#include <random>
#include <time.h>
#include <SDL_mixer.h>

#define WIDTH 1024
#define HEIGHT 768
#define FPS 60
#define BGS 2

#define emyW 100
#define emyH 100
#define obW 50
#define obH 50
#define miniObW 25
#define miniObH 25
#define emyBulletW 55
#define emyBulletH 50
#define playerSizeW 149
#define playerSizeH 198
#define emyBulletSpeed 4
#define playBulletSpeed 5
using namespace std;

class Bullet {
public: //members
	bool m_active = true; //unique
	SDL_Rect m_dst; //unique
public: //methods
	Bullet(int x, int y) {
		m_dst = { x - 2, y - 2, 4, 4 };
	}
	void update() {
		m_dst.y -= playBulletSpeed;
		if (m_dst.y < 0) {// if bullet get off the screen
			m_active = false;
		}
	}
};