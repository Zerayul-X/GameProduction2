#pragma once
#include "SDL.h"
#include "Sprite.h"


class Obstacles : public Sprite
{
public:
	bool m_active = true;
	void update();
	Obstacles(SDL_Rect d = { 0,0,0,0 });
	~Obstacles();
};

