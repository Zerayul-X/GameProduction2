#include "EnemyBullet.h"

#define HEIGHT 768



void EnemyBullet::update()
{
	m_dst.y += emyBulletSpeed; // speed.
	if (m_dst.y >= HEIGHT) // Off-screen.
	{
		m_active = false;
	}
}

EnemyBullet::EnemyBullet(SDL_Rect d)
{
	m_dst = d;
}

EnemyBullet::~EnemyBullet()
{
}
