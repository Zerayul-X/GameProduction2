#include "Enemy.h"
#include <time.h>
#include <random>
#define HEIGHT 768
#define WIDTH 1024
#define enemyBulletW 55
#define enemyBulletH 50
void Enemy::spawnBullet()
{
	bulletVec->push_back(new EnemyBullet({ m_dst.x, m_dst.y, enemyBulletW, enemyBulletH }));

	Mix_PlayChannel(m_channel, m_pSound, 0);
}

void Enemy::update()
{
	srand((unsigned)time(NULL));
	if (rand() % 3 == 0) {
		m_dst.x += 1;
	}
	else if (rand() % 3 == 1) {
		m_dst.x -= 1;
	}

	m_dst.y += 2;

	if (m_bulletTimer++ == m_timerMax)
	{
		m_bulletTimer = 0;
		spawnBullet();
	}
	if (m_dst.y >= HEIGHT + m_dst.h / 4) {// if enemy get off the screen
		m_dst.y = HEIGHT + m_dst.h / 4;
		m_active = false;
	}
	if (m_dst.x <= 0 - m_dst.w / 4) {// if enemy get off the screen
		m_dst.x = 0 - m_dst.w / 4;
		m_active = false;
	}
	if (m_dst.x >= WIDTH + m_dst.w / 4) {// if enemy get off the screen
		m_dst.x = WIDTH + m_dst.w / 4;
		m_active = false;
	}
}

Enemy::Enemy(SDL_Rect d, vector<EnemyBullet*>* bVec, Mix_Chunk * s, int c, int t)
{
	m_dst = d;
	bulletVec = bVec;
	m_pSound = s;
	m_channel = c;
	m_timerMax = t;
}

Enemy::~Enemy()
{
}
