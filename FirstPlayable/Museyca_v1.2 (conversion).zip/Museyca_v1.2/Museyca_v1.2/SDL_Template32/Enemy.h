#pragma once
#include <vector>
#include "EnemyBullet.h"
#include "SDL_mixer.h"

using namespace std;
class Enemy : public Sprite
{
public:
	//SDL_Rect m_dst;
	int m_bulletTimer = 0, m_timerMax, m_channel;
	vector<EnemyBullet*>* bulletVec; // A pointer to a vector. NOT a vector on its own.
	bool m_active = true;
	Mix_Chunk* m_pSound;
	void spawnBullet();
	void update();
	Enemy(SDL_Rect d = { 0,0,0,0 }, vector<EnemyBullet*>* bVec = nullptr, Mix_Chunk* s = nullptr, int c = 0, int t = 120);
	~Enemy();
};

