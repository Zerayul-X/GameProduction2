#include "SmallObstacle.h"
#include <time.h>
#include <random>
const int WIDTH = 1024;

void SmallObstacle::update()
{
	int tempSpeed;
	srand((unsigned)time(NULL));
	tempSpeed = rand() % 5 + 3;
	m_dst.x += tempSpeed;
	if (m_dst.x >= WIDTH + m_dst.w) {// if obstacles get off the screen
		m_dst.x = WIDTH + m_dst.w;
		m_active = false;
	}
}

SmallObstacle::SmallObstacle(SDL_Rect d)
{
	m_dst = d;
}

SmallObstacle::~SmallObstacle()
{
}
