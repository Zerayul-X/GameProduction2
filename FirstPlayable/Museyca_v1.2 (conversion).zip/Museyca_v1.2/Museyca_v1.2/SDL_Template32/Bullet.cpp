#include "Bullet.h"
#define playerBulletSPD 5


void Bullet::update()
{
	m_dst.y -= playerBulletSPD;
	if (m_dst.y < 0)
	{// if bullet get off the screen
		m_active = false;
	}
}

Bullet::Bullet(int x, int y)
{
	m_dst = { x - 2, y - 2, 4, 4 };
}

Bullet::~Bullet()
{

}
