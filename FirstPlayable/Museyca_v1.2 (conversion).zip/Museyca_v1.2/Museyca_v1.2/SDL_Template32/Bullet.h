#pragma once
#include "SDL.h"

class Bullet
{
public:
	bool m_active = true;
	SDL_Rect m_dst;
	void update();
	Bullet(int x, int y);
	~Bullet();
};

