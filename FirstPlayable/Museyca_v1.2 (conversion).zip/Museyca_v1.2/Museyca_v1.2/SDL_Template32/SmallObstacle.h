#pragma once
#include "SDL.h"
#include "Sprite.h"

class SmallObstacle : public Sprite
{
public:
	bool m_active = true;
	void update();
	SmallObstacle(SDL_Rect d = { 0,0,0,0 });
	~SmallObstacle();
};

