#pragma once
#include "SDL.h"
#include "Sprite.h"
class EnemyBullet : public Sprite
{
public:
	int emyBulletSpeed;
	bool m_active = true;
	void update();
	EnemyBullet(SDL_Rect d);
	~EnemyBullet();
};

