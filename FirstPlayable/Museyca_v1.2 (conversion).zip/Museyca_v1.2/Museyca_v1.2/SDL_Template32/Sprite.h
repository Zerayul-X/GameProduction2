#pragma once
#include "SDL.h"
class Sprite
{
private:

public:
	SDL_Rect m_dst;
	Sprite();
	~Sprite();
};

